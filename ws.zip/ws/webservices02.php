<?php
    require("webservices02_config.php");
    $datos = array();
    $datosFila = array();
    $accion = "";
    if(isset($_POST["accion"])){
        $accion = $_POST["accion"];
    }

    if($accion=="listar_contactos"){
        $filtro = $_POST["filtro"];
        $consulta = "select * from personas WHERE (nombre LIKE '%$filtro%' OR apellido LIKE '%$filtro%'
        OR telefono LIKE '%$filtro%') order by apellido ASC";

        $idConexion = conectar();
        $query = mysqli_query($idConexion,$consulta);
        $nfilas = mysqli_num_rows($query);
        while($aDatos = mysqli_fetch_array($query)){
            $jsonfila = array();
            $id_persona = $aDatos["id_persona"];
            $nombreCompleto = $aDatos["nombre"] ." ". $aDatos["apellido"];
            $telefono = $aDatos["telefono"];
            $direccion = $aDatos["direccion"];
            $jsonfila["id_persona"] = $id_persona;
            $jsonfila["nombre"] = $aDatos["nombre"];
            $jsonfila["apellido"] = $aDatos["apellido"];
            $jsonfila["telefono"] = $telefono;
            $jsonfila["direccion"] = $direccion;
            $datosFila[] = $jsonfila;
        }
        desconectar($idConexion);
        $datos["resultado"] = array_values($datosFila);
    }else if($accion=="agregar_contacto"){
        if($_POST){
            $nombre = $_POST["nombre"];
            $apellido = $_POST["apellido"];
            $telefono = $_POST["telefono"];
            $direccion = $_POST["direccion"];
            $idConexion = conectar();
            $consulta = "INSERT INTO personas (nombre,apellido,telefono,direccion)
            VALUES ('$nombre','$apellido','$telefono','$direccion')";
            if(mysqli_query($idConexion,$consulta)){
                $estado = "1";
            }else{
                $estado = "Error Interno: ". mysqli_error($idConexion);
            }
            desconectar($idConexion);
            $datos["estado"] = $estado;
        }
    }else if($accion=="modificar_contacto"){
        //UPDATE
        $id_persona = $_POST["id_persona"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];

        $idConexion = conectar();
        //Construir una Consulta
        $consulta = "UPDATE personas SET nombre='$nombre',apellido='$apellido',telefono='$telefono',
        direccion='$direccion' WHERE id_persona='$id_persona'";
        if(mysqli_query($idConexion,$consulta)){
            $estado = "1";
        }else{
            $estado = "0";
        }
        desconectar($idConexion);
        $datos["estado"] = $estado;
    }else if($accion=="eliminar_contacto"){
        //DELETE
        $id_persona = $_POST["id_persona"];

        $idConexion = conectar();
        //Construir una Consulta
        $consulta = "DELETE FROM personas WHERE id_persona='$id_persona'";
        if(mysqli_query($idConexion,$consulta)){
            $estado = "1";
        }else{
            $estado = "0";
        }
        desconectar($idConexion);
        $datos["estado"] = $estado;
    }
    echo json_encode($datos);
?>


