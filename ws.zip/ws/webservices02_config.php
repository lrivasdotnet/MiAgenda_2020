<?php
    function conectar(){
        $server = "localhost";
        $username = "root";
        $pass = "root";
        $bd = "agenda";
        $idConexion = mysqli_connect($server,$username,$pass,$bd);
        if(!$idConexion){
             $idConexion = mysqli_error($idConexion);
        }
        return $idConexion;
    }
    function desconectar($idConexion){
        try{
            mysqli_close($idConexion);
            $estado = 1;
        }catch(Exception $e){
            $estado = 0;
        }
        return $estado;
    }
?>