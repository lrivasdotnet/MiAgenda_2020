-- ----------------------------
-- Table structure for personas
-- ----------------------------
DROP TABLE IF EXISTS `personas`;
CREATE TABLE `personas` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  PRIMARY KEY (`id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of personas
-- ----------------------------
INSERT INTO `personas` VALUES ('2', 'Miguel Alberto', 'Perez', '9283-1222', 'San Salvador');
INSERT INTO `personas` VALUES ('4', 'Maria', 'Andrade', '2837-2893', 'San Miguel');
INSERT INTO `personas` VALUES ('5', 'Miguel', 'Chavez', '2839-2893', 'Usulutan');
INSERT INTO `personas` VALUES ('6', 'hdsajhk', 'hjkhk', '789876', '321jkdh');
INSERT INTO `personas` VALUES ('7', 'luis', 'rivas', '49894', 'kskdkf');
